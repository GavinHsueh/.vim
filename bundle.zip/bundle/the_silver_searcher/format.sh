#!/bin/bash

CLANG_FORMAT=clang-format-3.5

$CLANG_FORMAT -i src/*.c
